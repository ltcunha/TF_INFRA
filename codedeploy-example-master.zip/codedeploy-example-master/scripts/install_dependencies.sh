#!/bin/bash

sudo apt-get update
sudo apt-get install -y python2.7 python-pip
pip install Flask
